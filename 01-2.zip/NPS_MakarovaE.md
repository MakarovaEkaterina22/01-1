﻿\*\*Визуализация входных и выходных результатов

На дашборд [NPS\_makarovak](https://datalens.yandex.ru/aijhzqo69kli1-nps-makarovak)
